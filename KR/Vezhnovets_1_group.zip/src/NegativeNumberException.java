public class NegativeNumberException  extends Exception{
    NegativeNumberException(String s) {
        super(s);
    }
}
