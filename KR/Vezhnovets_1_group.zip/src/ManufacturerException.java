public class ManufacturerException extends Exception{
    ManufacturerException(String s) {
        super(s);
    }
}
