public class EnumIncorrectException extends Exception{
    public EnumIncorrectException(String s) {
        super(s);
    }
}
